
public class Grafo {
    NodoGrafo ini,fin;
    
    public Grafo(){
        ini=fin=null;
    }
    
    public boolean insertarNodo (char v){
        NodoGrafo nuevo = new NodoGrafo(v);
        
        if(nuevo==null){
            return false;
        }
        
        if(ini==null && fin==null){
            ini=fin=nuevo;
            return true;
        }
        
        fin.sig=nuevo;
        nuevo.ant=fin;
        fin=nuevo;
        
        return true;
    }
    
    public boolean insertarArista(char orig, char dest){
        NodoGrafo origen=buscarNodoGrafo(orig);     
        if(origen==null){
            return false;
        }
        
        NodoGrafo destino = buscarNodoGrafo(dest);
        if(destino==null){
            return false;
        }
        
        NodoArista temp=new NodoArista(destino);
        if(temp==null){
            return false;
        }    
        
        if(origen.aristas==null){
            origen.aristas=temp;
            return true;
        }
        
        NodoArista t2 = origen.aristas;
        while(t2.sig!=null){
            t2=t2.sig;
        }
        
        t2.sig=temp;
        temp.ant=t2;
        return true;
    }
    
    private NodoGrafo buscarNodoGrafo(char valorBuscado){
        NodoGrafo temp=ini;
        
        do{
            if(temp.valor==valorBuscado){
                return temp;
            }
            temp=temp.sig;
        }while(temp!=null);
        return temp;
    }
    
    public boolean buscarArista(char orig, char dest){
        NodoGrafo origen = buscarNodoGrafo(orig);
        if(origen==null){
            return false;
        }
        if(origen.aristas==null){
            return false;
        }
        NodoArista temp = origen.aristas;
        
        return temp.direccion.valor==dest;
    }
    
    public boolean eliminarArista(char orig, char dest){
        NodoGrafo origen = buscarNodoGrafo(orig);
        if(origen==null){
            return false;
        }
        
        if(origen.aristas==null){
            return false;
        }
        
        NodoArista temp = origen.aristas;
        
        do{
            if(temp.direccion.valor==dest){
                if(temp==origen.aristas){
                    origen.aristas=temp.sig;
                    temp.direccion=null;
                    temp.sig=null;
                    origen.aristas.ant=null;
                    return true;
                    
                } else {
                    if(temp.sig==null){
                        temp.ant.sig=null;
                        temp.direccion=null;
                        temp.ant=null;
                        return true;
                    }
                    temp.ant.sig=temp.sig;
                    temp.sig.ant=temp.ant; 
                    temp.sig=temp.ant=null;
                    temp.direccion=null;
                    return true;
                }    
            }
            temp = temp.sig;
        }while(temp!=null);
        return false;
    }
    
    public boolean eliminarNodo(char v){
        if(ini==null && fin==null){
            return false;
        }
        
        NodoGrafo nodoAEliminar= buscarNodoGrafo(v);
        if(nodoAEliminar==null){
            return false;
        }
        
        //VERIFICAR SI EL NODO_A_ELIMINAR ES ISLA
        //Caso 1 (que el no tenga aristas)
        if(nodoAEliminar.aristas!=null){
            return false;
        }
        //Caso 2 (que otro nodo no tenga aristas hacia nodo_a_eliminar)
        for(NodoGrafo temp=ini;temp!=null;temp=temp.sig){
            if(encontarAristas(temp,nodoAEliminar)==true){
                return false;
            }
        }
        if(ini==fin && ini==nodoAEliminar){
            ini=fin=null;
            return true;
        }
        //Eliminando si el nodoAEliminar está en INI
        if(ini==nodoAEliminar){
            NodoGrafo temp =ini.sig;
            ini.sig=null;
            temp.ant=null;
            ini=temp;
            return true;
        }
        //Eliminando si el nodoAEliminar está en FIN
        if(fin==nodoAEliminar){
            NodoGrafo temp=fin.ant;
            temp.sig=null;
            fin.ant=null;
            fin=temp;
            return true;
        }
        //Eliminando si el nodoAEliminar está en "MEDIO"
        nodoAEliminar.ant.sig=nodoAEliminar.sig;
        nodoAEliminar.sig.ant=nodoAEliminar.ant;
        nodoAEliminar.sig=nodoAEliminar.ant=null;
        return true;
    }

    private boolean encontarAristas(NodoGrafo temp, NodoGrafo nodoAEliminar) {
        for(NodoArista temp2=temp.aristas;temp2!=null;temp2=temp2.sig){
            if(temp2.direccion==nodoAEliminar){
                return true;
            }
        }
        return false;
    }
    
    public NodoGrafo ini(){
        return ini;
    }
    
    public String mostrarNodos(){
        if(ini==null && fin==null){
            return "No hay nodos";
        }
        return mostrarNodos(ini);
    }
    public String mostrarNodos(NodoGrafo temp){
        if(temp==null){
            return "";
        }
        return "    "+temp.valor+"\n"+mostrarNodos(temp.sig);
    }
}
